update CostsSource
set title="Vkontakte"
where title="vkontakte.ru";

update CostsSource
set class="BampoManager::ForeignCosts::Vkontakte"
where title="Vkontakte";

update CostsSource
set manual=1
where title in ("facebook.com","контекст","другие");
