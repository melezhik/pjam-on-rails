update Line l
set l.profitability = 50
where l.`type` = 'sitePixel' and l.profitability is null;

