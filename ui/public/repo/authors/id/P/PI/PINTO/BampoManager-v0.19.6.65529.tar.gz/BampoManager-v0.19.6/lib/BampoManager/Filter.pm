package BampoManager::Filter;

use Moose;
use MooseX::Storage;

with Storage;

1;

