insert into CostsSource (title, class, manual)
values ('YandexDirect', 'BampoManager::ForeignCosts::YandexDirect', 0);
