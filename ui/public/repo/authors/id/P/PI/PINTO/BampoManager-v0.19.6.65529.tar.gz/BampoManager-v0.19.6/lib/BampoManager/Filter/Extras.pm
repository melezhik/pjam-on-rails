package BampoManager::Filter::Extras;

use Moose;
use namespace::autoclean;

extends 'BampoManager::Filter';
with (
    'BampoManager::Filter::Role::ExtraCPoints',
    'BampoManager::Filter::Role::ExtraPlacements',
);

__PACKAGE__->meta->make_immutable;
