package BampoManager::Filter::CPoint::DailyStat;

use Moose;
use namespace::autoclean;

extends 'BampoManager::Filter';

with (
    'BampoManager::Filter::Role::StatPeriod',
    'BampoManager::Filter::Role::ExtraPlacements',
);


__PACKAGE__->meta->make_immutable;
