
-- -----------------------------------------------------
-- Update table `BannerFormat`
-- -----------------------------------------------------

UPDATE `BannerFormat`
SET `archived` = 1
WHERE `title` IN (
  "120x300",
  "200x300",
  "600x90",
  "Preloader"
);
