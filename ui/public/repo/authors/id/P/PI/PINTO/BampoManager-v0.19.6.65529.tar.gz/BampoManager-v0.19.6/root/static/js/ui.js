function showDialog (dialog) {
  document.getElementById('dialogs').style.display='block';
  document.getElementById('mask').style.display='block';
  document.getElementById(dialog).style.display='block';
}
function hideDialog (dialog) {
  document.getElementById('dialogs').style.display='none';
  document.getElementById('mask').style.display='none';
  document.getElementById(dialog).style.display='none';
  document.getElementById(dialog).innerHTML = '';
}