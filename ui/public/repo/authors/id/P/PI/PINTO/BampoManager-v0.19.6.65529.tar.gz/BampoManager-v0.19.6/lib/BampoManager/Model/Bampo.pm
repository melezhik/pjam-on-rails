package BampoManager::Model::Bampo;

use strict;
use base 'Catalyst::Model::DBIC::Schema';

__PACKAGE__->config(
    schema_class => 'BampoManager::Schema',
);

1;

