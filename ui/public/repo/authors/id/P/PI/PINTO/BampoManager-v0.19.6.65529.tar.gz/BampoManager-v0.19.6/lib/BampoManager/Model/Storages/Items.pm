package BampoManager::Model::Storages::Items;

use Moose;
use namespace::autoclean;

extends 'Catalyst::Model::DBIC::Schema';

use Adriver::Dictionary::Schema;

__PACKAGE__->config(
    schema_class => 'Adriver::Dictionary::Schema',
);

__PACKAGE__->meta->make_immutable;

