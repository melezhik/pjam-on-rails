package BampoManager::Filter::Role::Sortable;

use Moose::Role;

has sorted_column => (
    is => 'ro',
    isa => 'Str',
);


1;

