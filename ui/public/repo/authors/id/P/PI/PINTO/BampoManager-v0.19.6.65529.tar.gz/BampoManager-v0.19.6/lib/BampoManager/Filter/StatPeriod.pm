package BampoManager::Filter::StatPeriod;

use Moose;
use namespace::autoclean;

extends 'BampoManager::Filter';
with 'BampoManager::Filter::Role::StatPeriod';

__PACKAGE__->meta->make_immutable;
